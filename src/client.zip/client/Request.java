package client;

import protocol.MessageTypes;
import protocol.Protocol;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Request {

    private BufferedReader reader;
    private MessageTypes type;
    private String hash;
    private byte originalLength;
    private String originalRangeStart;
    private String originalRangeEnd;

    private Protocol protocol;

    public Request(String teamName, Protocol protocol) {
        this.reader = new BufferedReader(new InputStreamReader(System.in));
        this.protocol = protocol;
        this.type = MessageTypes.DISCOVER;
        this.originalRangeStart = "";
        this.originalRangeEnd = "";
        try {
            getUserInput(teamName);
        } catch (IOException e) {
            e.printStackTrace();
            throw new IllegalArgumentException();
        }
    }

    private void getUserInput(String teamName) throws IOException, NumberFormatException {
        System.out.println("Welcome to " + teamName + ". Please enter the hash:");
        this.hash = reader.readLine();
        if(hash.length() > protocol.getMessageHashLength()) {
            throw new IllegalArgumentException();
        }
        System.out.println("Please enter the input string length:");
        this.originalLength = Byte.parseByte(reader.readLine());
    }

    public void setRequest() {
        this.type = MessageTypes.REQUEST;
    }

    public void setRanges(String originalRangeStart, String originalRangeEnd) {
        this.originalRangeStart = originalRangeStart;
        this.originalRangeEnd = originalRangeEnd;
    }

    public byte getType() {
        return type.getType();
    }

    public String getHash() {
        return hash;
    }

    public byte getOriginalLength() {
        return originalLength;
    }

    public String getOriginalRangeStart() {
        return originalRangeStart;
    }

    public String getOriginalRangeEnd() {
        return originalRangeEnd;
    }

}
