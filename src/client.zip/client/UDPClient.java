package client;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

import protocol.Protocol;
import utils.HashCracker;
import protocol.Message;
import protocol.MessageTypes;

public class UDPClient implements Runnable {

    private final int SERVER_PORT = 3117;
    private final int GATHER_WAIT_TIME = 1000;
    private final int TIMEOUT = 1500;

    private DatagramSocket socket;
    private Protocol protocol;
    private Thread serverListener, serverResponder;
    private BlockingQueue<Message> serverResponses;
    private List<Message> activeServers;
    private boolean running;

    public final static Object LOCK = new Object();

    public UDPClient() {
        this.protocol = new Protocol();
        this.serverResponses = new LinkedBlockingDeque<>();
        this.activeServers = new LinkedList<>();
    }

    public void startServerListener() {
        this.serverListener = new Thread(() -> {
            while(running) {
                byte[] buffer = new byte[protocol.getMessageSize()];
                try {
                    DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                    socket.receive(packet);
                    serverResponses.add(new Message(packet.getAddress(), packet.getPort(), packet.getData()));
                    synchronized (LOCK) {
                        LOCK.notifyAll();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
        serverListener.start();
    }

    public void startServerResponder() {
        this.serverResponder = new Thread(() -> {
            while (running) {
                try {
                    synchronized (LOCK) {
                        while (serverResponses.isEmpty()) LOCK.wait();
                    }
                    Message message = serverResponses.poll();
                    parseMessage(message);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        serverResponder.start();
    }

    private void parseMessage(Message message) {
        MessageTypes messageType = MessageTypes.valueOf(message.getData()[protocol.getMessageTypeIndex()]);
        switch(messageType) {
            case OFFER:
                System.out.println("Active server " + message.getAddress() + ":" + message.getPort() +" sent an offer.");
                activeServers.add(message);
                break;
            case ACK:
                printResult(message);
                break;
            case NACK:
                System.out.println("Server at " +message.getAddress()+ ":" + message.getPort() +" returned NACK.");
                break;
            default:
                break;
        }
    }

    private void printResult(Message message) {
        int dataIndex = protocol.getMessageStartRange();
        byte[] messageData = message.getData();
        StringBuilder sb = new StringBuilder();
        while(messageData[dataIndex] != protocol.NULL) {
            sb.append((char) messageData[dataIndex++]);
        }
        System.out.println("The input string is: " + sb.toString());
    }

    private void start() throws SocketException {
        this.socket = new DatagramSocket();
        this.running = true;
        socket.setBroadcast(true);
        startServerListener();
        startServerResponder();
    }

    public void broadcastRequest(Request request) throws IOException, InterruptedException {
        final InetAddress BROADCAST_ADDRESS = InetAddress.getByName("localhost"); // CHANGE TO 255.255.255.255
        byte[] discoverMessage = protocol.createMessage(request.getType(), request.getHash(), request.getOriginalRangeStart(), request.getOriginalRangeEnd());
        socket.send(new DatagramPacket(discoverMessage, discoverMessage.length, BROADCAST_ADDRESS, SERVER_PORT));
        synchronized (this) {
            this.wait(GATHER_WAIT_TIME);
        }
    }

    /**
     * Divides to @param partsCount equal ranges of character arrays starting from
     * 'a' * @param len to 'z' * @param len.
     * Ex. len := 3, partsCount := 3 => output = [{aaa, iri}, {irj, riq}, {rir, zzz}]
     * where the corresponding strings in range are [5859, 5858, 5858].
     *
     * @param len         Length of the characters arrays to divide
     * @param partsCount The amount of parts to divide arrays into.
     */
    public Deque<Range> divideEqualStringRanges(byte len, int partsCount) {
        final int ALPHABETIC_COUNT = 26;
        final long TOTAL_RANGE = (long) Math.pow(ALPHABETIC_COUNT, len);
        final long RANGE_COUNT = (int) Math.ceil(TOTAL_RANGE / (double) partsCount) - 1;
        if (len < 1 || partsCount < 1)
            throw new IllegalArgumentException("Illegal arguments");
        Deque<Range> output = new LinkedList<>();
        long currentRangeStart = 0, currentRangeEnd = RANGE_COUNT;
        for (int i = 0; i < partsCount; ++i) {
            output.add(new Range(HashCracker.decimalToAlphabetic(currentRangeStart), HashCracker.decimalToAlphabetic(currentRangeEnd), len));
            currentRangeStart = currentRangeEnd + 1;
            currentRangeEnd += i == partsCount - 2 ? TOTAL_RANGE - currentRangeEnd - 1 : RANGE_COUNT;
        }
        return output;
    }

    private void sendRequestRanges(Request request) throws IOException {
        Deque<Range> ranges = divideEqualStringRanges(request.getOriginalLength(), activeServers.size());
        for(Message serverDetails : activeServers) {
            Range currRange = ranges.poll();
            request.setRanges(currRange.from, currRange.to);
            byte[] message = protocol.createMessage(request.getType(), request.getHash(), request.getOriginalRangeStart(), request.getOriginalRangeEnd());
            socket.send(new DatagramPacket(message, message.length, serverDetails.getAddress(), serverDetails.getPort()));
        }
    }

    private void terminate() {
        try {
            this.running = false;
            synchronized (LOCK) {
                LOCK.notifyAll();
            }
            serverListener.join();
            serverResponder.join();
            socket.close();
        } catch(InterruptedException e) {
            System.out.println("Client failed to terminate.");
        }
    }

    @Override
    public void run() {
        try {
            start();
            while (running) {
                try {
                    Request requestDetails = new Request(protocol.getTeamName(), protocol);
                    broadcastRequest(requestDetails);
                    requestDetails.setRequest();
                    try {
                        sendRequestRanges(requestDetails);
                        running = false;
                    } catch (IllegalArgumentException e) {
                        System.out.println("No server responded to message.");
                        terminate();
                    }
                } catch (IllegalArgumentException e) {
                    System.out.println("Invalid input provided!");
                    running = true;
                }
            }
        } catch (InterruptedException | IOException e) {
            e.printStackTrace();
        }
        terminate();
    }

    private static class Range {
        public String from;
        public String to;
        public long inRange;

        public Range(String from, String to, int len) {
            this.inRange = HashCracker.alphabeticToDecimal(to) - HashCracker.alphabeticToDecimal(from) + 1;
            this.from = String.format("%1$" + len + "s", from).replace(' ', 'a');
            this.to = String.format("%1$" + len + "s", to).replace(' ', 'a');
        }
    }
}
